import UIKit

public struct ShoppingItem {
    public let name: String
    public let priceCents: Int
    
    public init(name: String, priceInCents: Int) {
        self.name = name
        self.priceCents = priceInCents
    }
}

public func itemsUnder99Cents(item: ShoppingItem) -> Bool {
    return item.priceCents < 99
}

public func nameAndDescription(item: ShoppingItem) -> String {
    return "\(item.name): €\(Double(item.priceCents) / 100.0)"
}

public extension Array {
    
    public func transform<T>(to transform: ((Iterator.Element) -> T)) -> [T] {
        return map(transform)
    }
    
}

public extension Sequence where Iterator.Element == String {
    
    public func joined(by separator: String) -> String {
        return joined(separator: separator)
    }
    
}
