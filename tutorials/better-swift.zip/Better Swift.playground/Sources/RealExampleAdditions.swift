import Foundation
import UIKit
import Social

public func castAsExtensionItems(object: Any) -> NSExtensionItem? {
    return object as? NSExtensionItem
}

public func extractAllAttachments(item: NSExtensionItem) -> [NSItemProvider]? {
    return item.attachments.or([]).flatMap({ return $0 as? NSItemProvider })
}

public func onlyUrlItems(object: NSItemProvider) -> Bool {
    return object.hasItemConformingToTypeIdentifier("public.url")
}

public func loadUrl(using extensionContext: NSExtensionContext?) -> ((NSItemProvider) -> Void) {
    return { urlItem in
        urlItem.loadItem(forTypeIdentifier: "public.url", options: nil, completionHandler: { (result, error) in
            if let url = result as? NSURL {
                // Save the URL
            }
            extensionContext?.completeRequest(returningItems: []) { (expired) in
                print("did expire: \(expired)")
            }
        })
    }
}

public extension Array {
    
    public func then<ElementOfResult>(_ transform: ((Element) throws -> ElementOfResult?)) rethrows -> [ElementOfResult] {
        return try flatMap(transform)
    }
    
    public func attemptTo<ElementOfResult>(_ transform: ((Element) throws -> ElementOfResult?)) rethrows -> [ElementOfResult] {
        return try flatMap(transform)
    }
    
}
