import Foundation

public extension Optional {
    
    public func or(_ backup: Wrapped) -> Wrapped {
        if let wrapped = self {
            return wrapped
        }
        return backup
    }
    
}

public extension Optional where Wrapped: ExpressibleByArrayLiteral {
    
    public func orEmptyArray() -> Wrapped {
        let emptyArray: Wrapped = []
        return or(emptyArray)
    }
    
}
