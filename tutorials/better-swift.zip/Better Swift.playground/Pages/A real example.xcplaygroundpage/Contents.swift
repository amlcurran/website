//: [Previous](@previous)
//: # A real life example
/*:
 Here's a real life example where a combination of extensions and function pointers makes code far more readable than it was before
 */
import UIKit
import Social

class DemoShareViewController: SLComposeServiceViewController {
    
    override func didSelectPost() {
        let inputItems = extensionContext?.inputItems ?? []
        _ = inputItems
            .flatMap({ return $0 as? NSExtensionItem })
            .flatMap({ (extensionItem: NSExtensionItem) -> [NSItemProvider] in
                let attachments = extensionItem.attachments ?? []
                return attachments.flatMap({ (attachment) -> NSItemProvider? in
                    return attachment as? NSItemProvider
                })
            })
            .filter({ $0.hasItemConformingToTypeIdentifier("public.url") })
            .forEach({ (urlItem) -> Void in
                urlItem.loadItem(forTypeIdentifier: "public.url", options: nil, completionHandler: { (result, error) in
                    if let url = result as? NSURL {
                        // Save the URL
                    }
                    self.extensionContext!.completeRequest(returningItems: []) { (expired) in
                        print("did expire: \(expired)")
                    }
                })
            })
    }
}

/*:
 By using the following extensions defined [here](RealExampleAdditions.swift), we can reduce the code to the far simpler (and more explanatory):
 */

class DemoShareViewController2: SLComposeServiceViewController {
    
    override func didSelectPost() {
        let inputItems = extensionContext?.inputItems
        inputItems.orEmptyArray()
            .attemptTo(castAsExtensionItems)
            .then(extractAllAttachments)
            .joined()
            .filter(onlyUrlItems)
            .forEach(loadUrl(using: extensionContext))
    }
    
}

//: [Next](@next)
