//: ## Using extensions to improve an API

//: Here's an example where a loosely-defined API can be made clearer. Take adding a foreground color to a `NSMutableAttributedString`:
import UIKit

let string = "Hello world! Wie geht's?"
let attributedString = NSMutableAttributedString(string: string)
let range = (attributedString.string as NSString).range(of: "Hello")
attributedString.addAttributes([NSForegroundColorAttributeName: UIColor.red], range: range)

/*: 
 Using the standard NSMutableAttributedString API in Swift isn't great, as it is not type-safe and there are bridging difficulties with `Range` and `NSRange`.
 
 Here we can use an extension to better express our intention, at a higher level.
*/
extension NSMutableAttributedString {
    
    func setForegroundColor(_ color: UIColor, forText text: String) {
        let range = (string as NSString).range(of: text)
        if (range.location != NSNotFound) {
            addAttributes([NSForegroundColorAttributeName: color], range: range)
        }
    }
    
}

//: This extension makes what is happening much clearer:
attributedString.setForegroundColor(.red, forText: "Hello")

/*: 
 Notice here that we're not having to expose the intricasies of Range/NSRange incompatibility, and are also able to reduce runtime errors by enforcing we set a `UIColor` instead of any object like in the `addAttributes()` method.
 */

//: ## Augmenting operators with extensions
/*:
 
 A really cool extension is on `Optional` - a lot of operators aren't particularly clear in what they do, so why not wrap operators with real, descriptive, methods?
*/
let maybeInt = Int("4")
let addedUsingOperator = (maybeInt ?? 0) + 3
let addedUsingMethod = maybeInt.or(0) + 3

//: [Next](@next)
