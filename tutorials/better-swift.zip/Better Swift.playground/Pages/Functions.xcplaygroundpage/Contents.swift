//: ## Using functions to abstract details
/*:
 Swift's higher-order functions allow you to pass functions as parameters. This is a really useful way of abstracting details, and combining with extensions can make functional programming very readable.
 
 Take the following piece of code. How long does it take you to figure out what it does?
 */
let items = [ShoppingItem(name: "Banana", priceInCents: 24),
             ShoppingItem(name: "Chocolate", priceInCents: 199),
             ShoppingItem(name: "Milk", priceInCents: 59),
             ShoppingItem(name: "Bread", priceInCents: 150)]
let shoppingList = items
    .filter({ $0.priceCents < 99})
    .map({ "\($0.name): €\(Double($0.priceCents) / 100.0)" })
    .joined(separator: ", ")

/*:
 By adding some functions we can make it far more obvious what is happening, and allow a reader of the code to not require knowing how things are happening:
 */
let newShoppingList = items
    .filter(itemsUnder99Cents)
    .map(nameAndDescription)
    .joined(separator: ", ")

/*:
 Perhaps even consider the application of extensions to make the code more readable, especially if you're doing similar things multiple times over
 */
let thirdShoppingList = items
    .filter(itemsUnder99Cents)
    .transform(to: nameAndDescription)
    .joined(by: ", ")

//: [Previous](@previous) | [Next](@next)
